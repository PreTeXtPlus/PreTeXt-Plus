import os
import lxml.etree as ET
import numpy as np
import math
import logging
import copy
import re
from pathlib import Path
from . import tags
from . import user_namespace as un
from . import utilities as util
from . import CTM
from . import label
from . import math_utilities as math_util
from . import annotations
from . import repeat

log = logging.getLogger('prefigure')

# regular expression to check if id is EPUB compliant
epub_id_check = re.compile('^[A-Za-z0-9_-]+$')

class Diagram:
    def __init__(self,
                 diagram_element,
                 filename,
                 diagram_number,
                 format,
                 output,
                 publication,
                 suppress_caption,
                 environment,
                 prefix):
        self.diagram_element = diagram_element
        self.filename = filename
        self.diagram_number = diagram_number
        self.format = format
        self.output = output
        self.suppress_caption = suppress_caption
        self.environment = environment
        self.prefix = prefix
        self.caption = ""

        # the original source may be modified while parsing
        # We will make a copy along with a dictionary linking
        # the copied elements to the original elements.
        # This will be used in the playground for annotating
        # the source
        self.diagram_element_copy = copy.deepcopy(self.diagram_element)
        self.source_to_copy = {}
        for source, cp in zip(self.diagram_element.iter(),
                                self.diagram_element_copy.iter()):
            self.source_to_copy[source] = cp
        self.source_to_svg = {}

        excluded = set()
        for ann in self.diagram_element.iter('annotations'):
            excluded.update(ann.iter())
        for el in self.diagram_element.iter():
            if el in excluded:
                continue
            for attr, val in el.attrib.items():
                if val in ('true', 'false'):
                    log.warning(
                        f'<{el.tag}> attribute {attr}="{val}": '
                        f'PreFigure uses "yes"/"no" for boolean attributes'
                    )

        self.add_default_annotations = True
        if (self.environment == 'pyodide' and
            len(self.diagram_element.xpath('.//annotations')) == 0
            ):
            self.add_default_annotations = False

        util.set_diagram(self)
        math_util.set_diagram(self)

        label.init(self.format, self.environment)

        # create the XML tree for the svg output
        svg_uri = "http://www.w3.org/2000/svg"
        xml_uri = "http://www.w3/org/1999/xml"

        nsmap = {None: svg_uri,
                 'xml': xml_uri}
        self.root = ET.Element("svg", nsmap = nsmap)

        # ids may get a suffix or a prefix
        self.add_id_prefix = False
        figure_id = 'figure'
        if self.format != 'tactile':
            self.add_id_prefix = True
            if self.environment == 'pyodide':
                import time
                import hashlib
                import base64

                nano_secs = time.time_ns()  # nanoseconds
                hash = hashlib.sha256(str(nano_secs).encode()).digest()
                hash_string = base64.urlsafe_b64encode(hash[-6:]).decode()
                self.id_prefix = f"prefig-{hash_string}-"
            else:
                if self.prefix is not None:
                    self.id_prefix = self.prefix +'-'
                else:
                    self.id_prefix = Path(self.filename).stem + '-'
                self.id_prefix = repeat.epub_clean(self.id_prefix)
            figure_id = self.id_prefix + figure_id

        self.id_suffix = ['']
        self.add_id(self.root, diagram_element.get('id', figure_id))

        # prepare the XML tree for annotations, if there are any
        self.annotations_root = None
        self.default_annotations = []

        # store annotation branches
        self.annotation_branches = {}
        self.annotation_branch_stack = []

        # set up the HTML tree for labels to send to MathJax
        self.label_group_dict = {}
        self.label_html_tree = ET.Element('html')
        self.label_html_body = ET.Element('body')
        self.label_html_tree.append(self.label_html_body)

        # dictionary for holding previously computed data
        self.source_to_data = {}

        # a dictionary for holding shapes
        self.shape_dict = {}

        # dictionary for saving graphical data
        self.saved_data = {}

        # each SVG element will have an id, we'll store a count of ids here
        self.ids = {}

        # track reusables that have been added for outlining
        self.reusables = {}

        # track textures that have been added for fill
        self.textures = {}

        # a dictionary to remember some network information
        self.network_coordinates = {}

        # stack for managing bounding boxes and clipping
        self.clippaths = []

        # stack for managing scales of coordinate systems
        self.scale_stack = []

        # list for legends
        self.legends = []

        # dictionary for label dimensions
        self.label_dims = {}

        

        # read in defaults from publication file
        self.external = None
        self.defaults = {}
        if publication is not None:
            for subelement in publication:
                if subelement.tag == 'external-root':
                    log.warning('<external-root> in publication file is deprecated')
                    log.warning('Use <directories> instead')
                    log.warning('See "Working with data" in the PreFigure documentation"')
                    external = subelement.get('name', None)
                    if external is not None:
                        self.external = external
                    else:
                        log.warning('<external-root> in publication file needs a @name')
                    continue
                self.defaults[subelement.tag] = subelement
            directories = publication.xpath('.//directories')
            if len(directories) > 0:
                directories = directories[0]
                data_directory = directories.get('data', None)
                if data_directory is not None:
                    self.external = data_directory

        templates = self.diagram_element.xpath('.//templates')
        if len(templates) > 0:
            templates_element = templates[0]
            for template in templates:
                templates_parent = template.getparent()
                templates_parent.remove(template)
            for child in templates_element:
                self.defaults[child.tag] = child

        author_annotations = self.diagram_element.xpath('.//annotations')
        self.author_annotations_present = len(author_annotations) > 0
        if self.author_annotations_present:
            self.check_annotation_ref(author_annotations[0])

        if self.defaults.get('macros', None) is not None:
            label.add_macros(self.defaults.get('macros').text)

    def check_annotation_ref(self, element):
        ref = element.get('ref', None)
        if ref is not None:
            if not bool(epub_id_check.fullmatch(ref)):
                log.error(f"@ref {ref} in an annotation has characters disallowed by EPUB")
                log.error("  We will replace these characters but there may be unexpected behavior")
                log.error("  Search for EPUB in the PreFigure documentation https://prefigure.org")
                ref = repeat.epub_clean(ref)
                element.set('ref', ref)
        for child in element:
            self.check_annotation_ref(child)

    def add_legend(self, legend):
        self.legends.append(legend)
        
    def add_label(self, element, group):
        self.label_group_dict[element] = [group, copy.deepcopy(self.ctm())]

    def set_caption(self, text):
        self.caption = text

    def caption_suppressed(self):
        return self.suppress_caption

    def get_external(self):
        return self.external

    def get_label_group(self, element):
        return self.label_group_dict.get(element)

    def register_label_dims(self, element, dimensions):
        self.label_dims[element] = dimensions

    def get_label_dims(self, element):
        dims = self.label_dims.get(element, None)
        if dims is None:
            log.error(f"Cannot find dimensions for a label")
        return dims

    def add_id(self, element, id = None):
        # We'll add an id attribute to the SVG element
        # If not specified, the id is obtained from a count of elements
        element.set('id', self.find_id(element, id))

    def find_id(self, element, id = None):
        # We'll add an id attribute to the SVG element
        # If not specified, the id is obtained from a count of elements
        suffix = ''.join(self.id_suffix)
        if id is None:
            self.ids[element.tag] = self.ids.get(element.tag, -1) + 1
            result_id = '__'+element.tag+'-'+str(self.ids[element.tag])+suffix
        else:
            if not id.endswith(suffix):
                result_id = id + suffix
            else:
                result_id = id
        result_id = self.prepend_id_prefix(result_id)
        return result_id

    def append_id_suffix(self, element):
        return self.find_id(element, element.get('id', None))

    def prepend_id_prefix(self, id):
        if not self.add_id_prefix:
            return id
        if id.startswith(self.id_prefix):
            return id
        return self.id_prefix + id
    
    def output_format(self):
        return self.format

    def set_output_format(self, format):
        self.format = format

    def get_environment(self):
        return self.environment

    def register_source_data(self, element, key, value):
        element_dict = self.source_to_data.get(element, None)
        if element_dict is None:
            element_dict = {}

        element_dict[key] = value
        self.source_to_data[element] = element_dict

    def get_source_data(self, element, key):
        element_dict = self.source_to_data.get(element, None)
        if element_dict is None:
            return None
        return element_dict.get(key, None)

    # get the HTML tree so that we can add text for labels
    def label_html(self):
        return self.label_html_body

    def save_network_coordinates(self, network, coordinates):
        self.network_coordinates[network] = coordinates

    def get_network_coordinates(self, network):
        return self.network_coordinates[network]

    # transform a point into SVG coordinates
    def transform(self, p):
        ctm, b = self.ctm_stack[-1]
        try:
            return ctm.transform(p)
        except:
            log.error(f"Unable to apply coordinate transform to {p}")
            return np.array([0,0])

    def inverse_transform(self, p):
        ctm, b = self.ctm_stack[-1]
        try:
            return ctm.inverse_transform(p)
        except:
            log.error(f"Unable to apply inverse coordinate transform to {p}")
            return np.array([0,0])

    def save_data(self, element, data):
        self.saved_data[element] = data

    def retrieve_data(self, element):
        return self.saved_data.get(element, None)

    def register_svg_element(self, source, svg, overwrite=True):
        source_copy = self.source_to_copy.get(source, None)
        if source_copy is None:
            return
        if overwrite or self.source_to_svg.get(source_copy, None) is None:
            self.source_to_svg[source_copy] = svg

    def annotate_source(self):
        if (self.environment == 'pyodide' and
            not self.author_annotations_present
            ):
            diagram_annotations = annotations.diagram_to_speech(
                self.diagram_element_copy,
                self.source_to_svg
            )
            annotations_root = ET.Element('annotations')
            annotations_root.append(diagram_annotations)
            annotations.annotations(annotations_root, self, None, None)

    def begin_figure(self):
        # set up the dimensions of the diagram in SVG coordinates
        dims = self.diagram_element.get('dimensions')
        try:
            if dims is None:
                width = un.valid_eval(self.diagram_element.get('width'))
                height = un.valid_eval(self.diagram_element.get('height'))
            else:
                width, height = un.valid_eval(dims)
        except:
            log.error("Unable to parse the dimensions of this diagram")
            return

        margins = self.diagram_element.get('margins', '[0,0,0,0]')
        if self.format == 'tactile':
            margins = self.diagram_element.get('tactile-margins', margins)
        try:
            margins = un.valid_eval(margins)
        except:
            log.error("Unable to parse margins={element.get('margins')}")
            return
        if not isinstance(margins, np.ndarray):
            margins = [margins] * 4
        self.margins = margins

        ctm = CTM.CTM()
        # tactile diagrams will be embossed on 11.5"x11" paper
        if self.format == 'tactile':
            total_width = width + margins[0] + margins[2]
            total_height = height + margins[1] + margins[3]
            diagram_aspect = total_width / total_height
            page_aspect = 10.5 / 8.8  # area available for graphics

            if diagram_aspect >= page_aspect:
                s = 756 / total_width
                lly = s * total_height + 79.2
                self.centerline = 378 + 36 # half of 756 + margin
            else:
                s = 633.6 / total_height
                lly = 712.8
                self.centerline = s*total_width/2 + 36
            self.bottomline = lly
            ctm.translate(36, lly)
            ctm.scale(s, -s)
            ctm.translate(margins[0], margins[1])
            self.root.set("width", "828")
            self.root.set("height", "792")

            # bounding rectangle
            '''
            rect = ET.SubElement(self.root, 'rect')
            rect.set('x', '0')
            rect.set('y', '0')
            rect.set('width', '828')
            rect.set('height', '792')
            rect.set('stroke', 'black')
            rect.set('fill', 'none')
            '''
        else:
            w = width + margins[0]+margins[2]
            h = height + margins[1]+margins[3]
            self.root.set("width", str(w))
            self.root.set("height", str(h))
            self.root.set("viewBox", f"0 0 {w} {h}")

            # initialize the CTM and push it onto the CTM stack
            ctm.translate(0, height + margins[1] + margins[3])
            ctm.scale(1,-1)
            ctm.translate(margins[0], margins[1])

        bbox = [0,0,width,height]
        un.enter_namespace('bbox', bbox)
        self.ctm_stack = [[ctm, bbox]]
        self.scale_stack = [['linear', 'linear']]

        # initialize the SVG element 'defs' and add the clipping path
        self.defs = ET.SubElement(self.root, 'defs')

        clippath = ET.Element('clipPath')
        ET.SubElement(clippath, 'rect',
                      attrib={
                             'x': util.float2str(margins[0]),
                             'y': util.float2str(margins[3]),
                             'width': util.float2str(width),
                             'height': util.float2str(height)
                         })

        self.push_clippath(clippath)

    def push_clippath(self, clippath):
        self.defs.append(clippath)
        self.add_id(clippath)
        self.clippaths.append(clippath.get('id'))

    def pop_clippath(self):
        self.clippaths.pop(-1)

    def push_scales(self, scales):
        self.scale_stack.append(scales)

    def pop_scales(self):
        self.scale_stack.pop(-1)

    def get_scales(self):
        return self.scale_stack[-1]

    def get_clippath(self):
        return self.clippaths[-1]
    
    def place_labels(self):
        label.place_labels(self,
                           self.filename,
                           self.root,
                           self.label_group_dict,
                           self.label_html_tree)

        for legend in self.legends:
            legend.place_legend(self)

        if self.format == 'tactile':
            # first we'll place the caption
            if len(self.caption) == 0:
                caption = label.nemeth_on
            else:
                self.caption = label.braille_translator.translate(
                    self.caption,
                    [0] * len(self.caption)
                )
                caption = self.caption + ' ' + label.nemeth_on

            gap = 3.6  # space between embossing dots

            text_element = ET.SubElement(self.root, 'text')
            text_element.text = caption
            text_element.set("x", "144")  # start in cell 7 per BANA, was 36
            text_element.set("y", "50.4")
            text_element.set('font-family', "Braille29")
            text_element.set('font-size', "29px")

            # add a nemeth off indicator at the bottom
            text_element = ET.SubElement(self.root, 'text')
            text_element.text = label.nemeth_off
            text_element.set('x', '36')
            y = self.bottomline + 12 * gap  # bottom of diagram + blank line
            y = label.snap_to_embossing_grid(y)
            text_element.set('y', util.float2str(y))
            text_element.set('font-family', "Braille29")
            text_element.set('font-size', "29px")
        
    def end_figure(self):
        # form the output filenames
        if self.diagram_number is None:
            suffix = ''
        else:
            suffix = '-' + str(self.diagram_number)

        input_dir = os.path.dirname(self.filename)
        basename = Path(self.filename).stem + suffix

        # perform the SVG 1.1 conversion if requested
        if self.output_format() == 'svg11':
            basename = basename + "-11"
            self.root = self.svg11_conversion(self.root)

        output_dir = os.path.join(input_dir, 'output')
        out = os.path.join(output_dir, basename)
        try:
            if not os.path.exists(output_dir):
                os.mkdir(output_dir)
            with ET.xmlfile(out + '.svg', encoding='utf-8') as xf:
                xf.write(self.root, pretty_print=True)
        except:
            log.error(f"Unable to write SVG at {out+'.svg'}")
            return

        # don't write out annotations in svg11 format
        if self.output_format() == 'svg11':
            return

        # if we're inside pretext, we'll also add an SVG1.1 version
        if self.environment == "pretext" and self.output_format() != "tactile":
            root11 = self.svg11_conversion(self.root)
            try:
                with ET.xmlfile(out + '-11.svg', encoding='utf-8') as xf:
                    xf.write(root11, pretty_print=True)
            except:
                log.error(f"Unable to write SVG at {out + '-11.svg'}")
                return

        if self.author_annotations_present and self.environment == "pretext":
            # we will write out a second version of the diagram
            # without the height and width attributes for diagcess use
            width = self.root.get('width')
            height = self.root.get('height')
            self.root.attrib.pop("height")
            self.root.attrib.pop("width")
            self.root.set('style', f'aspect-ratio: {width} / {height};')
            try:
                with ET.xmlfile(out + '-diagcess.svg', encoding='utf-8') as xf:
                    xf.write(self.root, pretty_print=True)
                self.root.attrib.pop('style')
            except:
                log.error(f"Unable to write SVG at {out+'-diagcess.svg'}")
                return

        if self.annotations_root is not None:
            diagram = ET.Element('diagram')
            diagram.append(self.annotations_root)
            et = ET.ElementTree(diagram)
            if self.environment == "pretext":
                output_file = out + '-annotations.xml'
            else:
                output_file = out + '.xml'
            try:
                et.write(output_file, pretty_print=True)
            except:
                log.error(f"Unable to write annotations in {output_file}")
                return
        else:
            try:
                os.remove(out+'.xml')
            except OSError:
                pass

            try:
                os.remove(out+'-annotations.xml')
            except OSError:
                pass


    # If we only want a string, we assemble the XML tree
    # consisting of the SVG and annotations and return as a string
    def end_figure_to_string(self):
        root = self.root
        if self.output_format() == 'svg11':
            root = self.svg11_conversion(root)
        svg_string = ET.tostring(root).decode('utf-8')
        annotation_string = None
        if self.annotations_root is not None and self.output_format() != 'svg11':
            diagram = ET.Element("diagram")
            diagram.append(self.annotations_root)
            annotation_string = ET.tostring(diagram).decode('utf-8')
        return svg_string, annotation_string

    # Here we parse the children of the given XML element
    # Resulting SVG elements will be placed below root
    def parse(self, element = None, root = None, outline_group = None):
        if element is None:
            element = self.diagram_element
        if root is None:
            root = self.root
        # strip out the namespace prefix
        element.tag = ET.QName(element).localname
        # We allow an element's attributes to be rewritten depending on
        # the format.  For instance, tactile diagrams sometimes require
        # modified attributes
        prefix = self.format + '-'
        for child in element:
            if child.tag is ET.Comment:
                continue
            child.tag = ET.QName(child).localname
            if child.get('at') is not None:
                child.set('id', child.get('at'))

            child_id = child.get('id', None)
            if child_id is not None:
                if not bool(epub_id_check.fullmatch(child_id)):
                    log.error(f"The id {child_id} has characters disallowed by EPUB")
                    log.error("  We will substitute disallowed characters to make the id EPUB compliant")
                    log.error("  Search for EPUB in the PreFigure documentation at https://prefigure.org")
                    child.set('id', repeat.epub_clean(child_id))

            # see if the publication flie has any defaults
            defaults = self.defaults.get(child.tag, None)
            if defaults is not None:
                for attr, value in defaults.attrib.items():
                    if child.get(attr, None) is None:
                        child.set(attr, value)
            # replace any format-specific attributes
            for attr, value in child.items():
                if attr.startswith(prefix):
                    child.set(attr[len(prefix):], value)
            try:
                tags.parse_element(child, self, root, outline_group)
            except Exception as e:
                log.error(f"Error in parsing element {child.tag}")
                log.error(str(e))
                return
            if (
                    child.get('annotate', 'no') == 'yes' and
                    root.get('data-outline', 'no') == 'no'
            ):
                tag = child.tag
                if tag != 'group' and tag != 'repeat':
                    annotation = ET.Element('annotation')
                    for attrib in ['id', 'text', 'sonify', 'circular', 'speech']:
                        if child.get(attrib, None) is not None:
                            annotation.set(attrib, child.get(attrib))
                    if annotation.get('text', None) is not None:
                        annotation.set('text',
                                       label.evaluate_text(annotation.get('text')))
                    if annotation.get('speech', None) is not None:
                        annotation.set('speech',
                                       label.evaluate_text(annotation.get('speech')))
                    self.add_annotation_to_branch(annotation)

    def ctm(self):
        return self.ctm_stack[-1][0]

    def bbox(self):
        return self.ctm_stack[-1][1]

    def ctm_bbox(self):
        return self.ctm_stack[-1]

    def get_margins(self):
        return self.margins

    def push_ctm(self, ctm_bbox):
        self.ctm_stack.append(ctm_bbox)

    def pop_ctm(self):
        return self.ctm_stack.pop(-1)

    def add_reusable(self, element):
        if self.has_reusable(element.get('id', 'none')):
            return
        self.defs.append(element)
        self.reusables[element.get('id')] = element

    def has_reusable(self, reusable):
        return self.reusables.get(reusable, None) is not None
    
    def get_reusable(self, reusable):
        return self.reusables.get(reusable, None)
    
    def push_id_suffix(self, suffix):
        self.id_suffix.append(suffix)

    def pop_id_suffix(self):
        self.id_suffix.pop(-1)

    def get_root(self):
        return self.root

    def apply_defaults(self, tag, element):
        default = self.defaults.get(tag, None)
        if default is not None:
            for attr, value in default.attrib.items():
                if element.get(attr, None) is None:
                    element.set(attr, value)

    # when a graphical component is outlined, we first add the component's path
    # to <defs> so that it can be reused, then we stroke it with a thick white
    def add_outline(self, element, path, parent, outline_width = None,
                    id = None):
        if outline_width is None:
            if self.output_format() == 'tactile':
                outline_width = 18
            else:
                outline_width = 4

        stroke = path.attrib.pop('stroke', 'none')
        width = path.attrib.pop('stroke-width', '1')
        fill = path.attrib.pop('fill', 'none')
        path.attrib.pop('stroke-dasharray', 'none')

        if id is None:
            self.add_id(element, element.get('id'))
            outline_id = element.get('id') + '-outline'
        else:
            outline_id = id + '-outline'
        path.set('id', outline_id)
        self.add_reusable(path)

        use = ET.SubElement(parent, 'use', attrib={       
            'fill': fill,
            'stroke-width': str(int(width) + outline_width),
            'stroke': 'white',
            'href': r'#' + outline_id
        }
        )
        # We need to be careful with arrow heads.  The references to
        # the arrow heads are in path, which is now a reusable.  We will
        # retrieve the references, change the references to point to the
        # outlined arrow heads, and add them to the use element.  In the
        # finish_outline function, we'll remove the references from the
        # reusable since otherwise we'll only see the original arrow heads
        for marker in ['marker-end', 'marker-start', 'marker-mid']:
            reference = path.get(marker, None)
            if reference is not None:
                reference = reference.replace(')', '-outline)')
                use.set(marker, reference)

    # after the outline of a graphical component is added, we then add the 
    # component itself on top of the outline
    def finish_outline(self, element, stroke, thickness, fill, parent, id=None):
        if id is None:
            id = element.get('id', 'none')
        use = ET.SubElement(parent, 'use', attrib={
            'id': id,
            'fill': str(fill),
            'stroke-width': str(thickness),
            'stroke': str(stroke),
            'stroke-dasharray': element.get('dash', 'none')
        }
        )
        self.register_svg_element(element, use)
        # labeled points and angle markers are in a <g> with the 
        # point's id.  To avoid duplicate id's, we'll remove the
        # id from the graphical component
        if element.get('id', 'none') == parent.get('id', 'none'):
            use.attrib.pop('id')

        # We have to clean up the arrow heads.  The references to the
        # arrow heads are in the reusable so we'll retrieve them and
        # and include them with the use element.
        element_id = id
        if element_id.endswith(self.id_suffix[-1]):
            reuse_handle = element_id + '-outline'
        else:
            reuse_handle = element.get('id')+self.id_suffix[-1]+'-outline'
        reusable = self.get_reusable(reuse_handle)
        use.set('href', r'#' + reuse_handle)
        for marker in ['marker-start', 'marker-end', 'marker-mid']:
            if reusable.get(marker, 'none') != 'none':
                use.set(marker, reusable.get(marker))
                reusable.attrib.pop(marker)

    def initialize_annotations(self):
        if self.annotations_root is not None:
            log.error('Annotations need to be in a single tree')
            return

        self.annotations_root = ET.Element('annotations')

    def add_default_annotation(self, annotation):
        if not self.add_default_annotations:
            return
        self.default_annotations.append(annotation)

    def get_default_annotations(self):
        return self.default_annotations

    def get_annotations_root(self):
        return self.annotations_root

    def add_annotation(self, annotation):
        self.annotations_root.append(annotation)

    def push_to_annotation_branch(self, annotation):
        if len(self.annotation_branch_stack) == 0:
            self.annotation_branches[annotation.get('id')] = annotation
        else:
            self.add_annotation_to_branch(annotation)
        self.annotation_branch_stack.append(annotation)

    def pop_from_annotation_branch(self):
        self.annotation_branch_stack.pop(-1)

    def add_annotation_to_branch(self, annotation):
        if len(self.annotation_branch_stack) == 0:
            id = annotation.get('id')
            id = self.prepend_id_prefix(id)
            self.annotation_branches[id] = annotation
            return
        self.annotation_branch_stack[-1].append(annotation)
        id = self.append_id_suffix(annotation)
        id = self.prepend_id_prefix(id)
        annotation.set('id', id)

    def get_annotation_branch(self, id):
        return self.annotation_branches.pop(id, None)

    def recall_shape(self, shape_id):
        return self.shape_dict.get(shape_id, None)

    def add_shape(self, shape):
        self.defs.append(shape)
        id = shape.get('id', shape.get('at'))
        self.shape_dict[id] = shape
        
    def get_shape(self, shape_id):
        shape = self.recall_shape(shape_id)
        if shape is not None:
            return shape
        
        paths = self.root.findall('path')
        for path in paths:
            if path.get('id', None) == shape_id:
                return path

        log.error(f"We cannot find a <shape> with id={shape_id}")
        return None

    def svg11_conversion(self, root):
        SVG_NS = "http://www.w3.org/2000/svg"
        XLINK_NS = "http://www.w3.org/1999/xlink"

        # Replace href with xlink:href in <use> and <image> elements
        for elem in root.iter('use', 'image'):
            if 'href' in elem.attrib:
                value = elem.attrib.pop('href')
                elem.attrib[f'{{{XLINK_NS}}}href'] = value

        # Handle arrow-head-end markers
        for defs in root.iter('defs'):
            for marker in list(defs):
                if marker.tag != 'marker':
                    continue
                marker_id = marker.get('id', '')
                if 'arrow-head-end' not in marker_id:
                    continue

                marker.set('orient', 'auto')

                start_marker = copy.deepcopy(marker)
                start_marker.set('id',
                                 marker_id.replace('arrow-head-end', 'arrow-head-start'))

                ref_x = float(start_marker.get('refX', 0))
                ref_y = float(start_marker.get('refY', 0))
                marker_width = float(start_marker.get('markerWidth', 0))
                marker_height = float(start_marker.get('markerHeight', 0))

                cx = marker_width / 2
                cy = marker_height / 2
                g = ET.Element('g')
                g.set('transform', f'rotate(180, {cx}, {cy})')

                for child in list(start_marker):
                    start_marker.remove(child)
                    g.append(child)

                start_marker.append(g)

                new_ref_x = marker_width - ref_x
                start_marker.set('refX', str(int(new_ref_x) if new_ref_x == int(new_ref_x) else new_ref_x))

                defs.append(start_marker)

        # Update marker-start references from arrow-head-end to arrow-head-start
        for elem in root.iter():
            value = elem.get('marker-start', '')
            if 'arrow-head-end' in value:
                elem.set('marker-start',
                         value.replace('arrow-head-end', 'arrow-head-start'))

        # Any other marker still carrying SVG 2's auto-start-reverse (e.g. the
        # mid-path arrowheads, referenced only by marker-mid where the two
        # values render identically) falls back to plain auto, which SVG 1.1
        # understands.
        for marker in root.iter('marker'):
            if marker.get('orient') == 'auto-start-reverse':
                marker.set('orient', 'auto')

        return root

    def add_texture(self, texture, color):
        tactile = self.output_format() == 'tactile'
        if tactile:
            color="#777"
        from . import repeat
        clean_color = repeat.epub_clean(color)
        texture_str = texture + '-' + color
        if self.textures.get(texture_str, None) is not None:
            return self.textures.get(texture_str)

        pattern = ET.SubElement(self.defs, 'pattern')
        pattern.set('x', '0')
        pattern.set('y', '0')
        pattern.set('patternUnits', 'userSpaceOnUse')

        if texture == 'horizontal':
            id = self.prepend_id_prefix(f'__horizontal_texture_{clean_color}')
            self.textures[texture] = id
            pattern.set('id', id)
            s = 7
            thickness = '2'
            if tactile:
                s = 9
                thickness = '1'
            pattern.set('width', f'{s}')
            pattern.set('height', f'{s}')
            line = ET.SubElement(pattern, 'line')
            line.set('x1', '-1')
            line.set('y1', '0')
            line.set('x2', f'{s+1}')
            line.set('y2', '0')
            line.set('stroke', color)
            line.set('stroke-width', thickness)

        if texture == 'vertical':
            id = self.prepend_id_prefix(f'__vertical_texture_{clean_color}')
            pattern.set('id', id)
            s = 7
            thickness = '2'
            if tactile:
                s = 9
                thickness = '1'
            pattern.set('width', f'{s}')
            pattern.set('height', f'{s}')
            line = ET.SubElement(pattern, 'line')
            line.set('x1', '0')
            line.set('y1', '-1')
            line.set('x2', '0')
            line.set('y2', f'{s+1}')
            line.set('stroke', color)
            line.set('stroke-width', thickness)

        if texture == 'diagonal':
            id = self.prepend_id_prefix(f'__diagonal_texture_{clean_color}')
            pattern.set('id', id)
            s = 9
            thickness = '1'
            if tactile:
                s = 13
                thickness = '1'
            pattern.set('width', f'{s}')
            pattern.set('height', f'{s}')
            for data in [[-1,1,1,-1], [-1,s+1,s+1,-1], [s-1,s+1,s+1,s-1]]:
                line = ET.SubElement(pattern, 'line')
                for field, value in zip(['x1','y1','x2','y2'], data):
                    line.set(field, str(value))
                line.set('stroke', color)
                line.set('stroke-width', thickness)

        if texture == 'backdiagonal':
            id = self.prepend_id_prefix(f'__backdiagonal_texture_{clean_color}')
            pattern.set('id', id)
            s = 9
            thickness = '1'
            if tactile:
                s = 13
                thickness = '1'
            pattern.set('width', f'{s}')
            pattern.set('height', f'{s}')
            for data in [[s-1,-1,s+1,1], [-1,-1,s+1,s+1], [-1,s-1,1,s+1]]:
                line = ET.SubElement(pattern, 'line')
                for field, value in zip(['x1','y1','x2','y2'], data):
                    line.set(field, str(value))
                line.set('stroke', color)
                line.set('stroke-width', thickness)

        if texture == 'dot':
            id = self.prepend_id_prefix(f'__dot_texture_{clean_color}')
            pattern.set('id', id)
            s = 8
            dot_size = 1.8
            if tactile:
                s = 9
                dot_size = 2
            s3 = math.sqrt(3)
            r = 2/s3 * s
            t = 1/s3 * s
            pattern.set('width', f'{2*s}')
            pattern.set('height', f'{2*s3*s}')
            for center in [[0,0], [0,r], [0,2*r], [s,t],
                           [s,2*r+t], [s,r+t]]:
                center[0] += dot_size
                center[1] += dot_size
                circle = ET.SubElement(pattern, 'circle')
                circle.set('cx', f'{center[0]}')
                circle.set('cy', f'{center[1]}')
                circle.set('r', f'{dot_size}')
                circle.set('fill', color)

        if texture == 'diamond':
            id = self.prepend_id_prefix(f'__diamond_texture_{clean_color}')
            pattern.set('id', id)
            s = 2.5
            if tactile:
                s = 5
            t = s*math.sqrt(3)
            pattern.set('width', f'{4*s}')
            pattern.set('height', f'{4*t}')
            for cx, cy in [[s,t],[3*s,3*t]]:
                path = ET.SubElement(pattern, 'path')
                path.set('d', f'M {cx} {cy+t} L {cx+s} {cy} L {cx} {cy-t} L {cx-s} {cy} Z')
                path.set('fill', color)

        self.textures[texture_str] = id
        return id
